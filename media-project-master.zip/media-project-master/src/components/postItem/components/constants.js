export default {
    COMMENT: 1,
    REPLY: 2,
};
