export const userConstants = {
  CURRENT_STATUS: 'CURRENT_STATUS',
  NAME: 'NAME',
};
