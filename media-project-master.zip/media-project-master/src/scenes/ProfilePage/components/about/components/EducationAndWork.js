import React from 'react';

const EducationAndWork = () => (
  <div className="ui-block">
    <div className="ui-block-title">
      <h6 className="title">Education And Work</h6>
    </div>
    <div className="ui-block-content">
      <div className="row" />
    </div>
  </div>
);

export default EducationAndWork;
